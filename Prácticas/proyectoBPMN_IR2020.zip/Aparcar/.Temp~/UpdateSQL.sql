-- estacionamiento [ent1]
create table "APP"."ESTACIONAMIENTO" (
   "OID"  integer  not null,
   "CALLE"  varchar(255),
   "ZONA"  varchar(255),
   "MATRICULA"  varchar(255),
   "TIEMPO"  integer,
   "FORMA_DE_PAGO"  varchar(255),
   "PRECIO"  numeric(19,2),
   "AVISO_FINAL_ESTACIONAMIENTO"  smallint,
   "HAY_FORMA_DE_PAGO"  smallint,
  primary key ("OID")
);


-- pago [ent2]
create table "APP"."PAGO" (
   "OID"  integer  not null,
   "NUMERO_DE_TARJETA"  varchar(255),
   "CADUCIDAD"  date,
   "NUMERO_SECRETO"  integer,
   "USUARIO"  varchar(255),
   "CONTRASE_A"  varchar(255),
   "NUMERO_DE_TELEFONO"  varchar(255),
   "CORRECTO"  smallint,
  primary key ("OID")
);


